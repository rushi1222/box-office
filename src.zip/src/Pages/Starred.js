import React from 'react'
import MainPagesLayout from './MainPagesLayout'

function Starred() {
  return (
    <MainPagesLayout>Starred</MainPagesLayout>
  )
}

export default Starred