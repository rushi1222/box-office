import React from 'react'

function GenereicNotFound() {
  return (
    <div>GenereicNotFound</div>
  )
}

export default GenereicNotFound