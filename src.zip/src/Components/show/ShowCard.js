import React from 'react'

const showCard = () => {
  return (
    <div>showCard</div>
  )
}

export default showCard